# Disegna e Disastra!

Party game multiplayer per browser, con stanze private e codice d'accesso.

## Avvio sul tuo computer
Serve Node.js 18 o superiore.

```bash
npm install
npm start
```

Apri `http://localhost:3000`.

## Come far giocare gli amici online
Per giocare da telefoni diversi anche fuori dalla stessa rete, il progetto deve essere pubblicato su un servizio che supporti Node.js e WebSocket (per esempio Render o Railway). Carica questa cartella come progetto, imposta il comando di avvio `npm start` e condividi con gli amici l'indirizzo pubblico. Tutti aprono lo stesso indirizzo e uno crea una stanza.

## Funzioni incluse
- Stanze private con codice
- Fino a 12 giocatori
- Turni di frase, disegno e interpretazione
- Area di disegno touch-friendly
- Rivelazione finale

## Nota
Questa è una prima versione giocabile. I dati delle stanze vivono in memoria: se il server si riavvia, le partite in corso si interrompono. Il gioco non salva account o cronologia.
