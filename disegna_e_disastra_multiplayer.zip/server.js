const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static("public"));

const rooms = new Map();
const WORDS = [
  "Un pinguino che guida una Ferrari", "Un nonno astronauta", "Un gatto che fa il DJ",
  "Un dinosauro al supermercato", "Una pizza innamorata", "Un calciatore su Marte",
  "Un fantasma che ha paura del buio", "Un polpo che suona la batteria",
  "Un cavallo con gli occhiali da sole", "Un robot che prepara la carbonara"
];

function code() { return crypto.randomBytes(3).toString("hex").toUpperCase(); }
function publicRoom(room) {
  return { code: room.code, players: [...room.players.values()].map(p => ({name:p.name, id:p.id})),
    phase: room.phase, round: room.round, totalRounds: room.totalRounds };
}
function broadcast(room) { io.to(room.code).emit("room-update", publicRoom(room)); }
function begin(room) {
  if (room.players.size < 2) return;
  room.phase = "writing"; room.round = 1; room.turns = [];
  room.order = [...room.players.keys()];
  room.prompts = new Map(); room.drawings = new Map(); room.guesses = new Map();
  room.order.forEach((id, i) => room.prompts.set(id, null));
  io.to(room.code).emit("game-start", { round: room.round, totalRounds: room.totalRounds });
  broadcast(room);
}
io.on("connection", socket => {
  socket.on("create-room", ({name}, cb) => {
    const c = code();
    const room = {code:c, players:new Map(), phase:"lobby", round:0, totalRounds:1};
    room.players.set(socket.id, {id:socket.id, name:String(name||"Giocatore").slice(0,18)});
    rooms.set(c, room); socket.join(c); socket.data.room=c;
    cb({ok:true, code:c, room:publicRoom(room)});
  });
  socket.on("join-room", ({code:c, name}, cb) => {
    c = String(c||"").toUpperCase().trim();
    const room = rooms.get(c);
    if (!room) return cb({ok:false, error:"Stanza non trovata. Controlla il codice."});
    if (room.phase !== "lobby") return cb({ok:false, error:"La partita è già iniziata."});
    if (room.players.size >= 12) return cb({ok:false, error:"La stanza è piena (massimo 12 giocatori)."});
    room.players.set(socket.id, {id:socket.id, name:String(name||"Giocatore").slice(0,18)});
    socket.join(c); socket.data.room=c; broadcast(room);
    cb({ok:true, code:c, room:publicRoom(room)});
  });
  socket.on("start-game", cb => {
    const room=rooms.get(socket.data.room);
    if (!room || room.players.size < 2) return cb?.({ok:false,error:"Servono almeno 2 giocatori."});
    if ([...room.players.keys()][0] !== socket.id) return cb?.({ok:false,error:"Solo chi ha creato la stanza può iniziare."});
    begin(room); cb?.({ok:true});
  });
  socket.on("submit-prompt", ({text}, cb) => {
    const room=rooms.get(socket.data.room);
    if (!room || room.phase!=="writing" || !room.players.has(socket.id)) return;
    const prompt=String(text||"").trim().slice(0,100);
    if (!prompt) return cb?.({ok:false,error:"Scrivi una frase prima di continuare."});
    room.prompts.set(socket.id,prompt);
    if ([...room.prompts.values()].every(Boolean)) {
      room.phase="drawing";
      room.order.forEach((id,i) => {
        const target=room.order[(i+1)%room.order.length];
        io.to(target).emit("your-task",{type:"draw", prompt:room.prompts.get(id), round:room.round});
      });
    }
    cb?.({ok:true}); broadcast(room);
  });
  socket.on("submit-drawing", ({data}, cb) => {
    const room=rooms.get(socket.data.room);
    if (!room || room.phase!=="drawing" || !room.players.has(socket.id)) return;
    if (typeof data!=="string" || data.length>1800000) return cb?.({ok:false,error:"Disegno non valido."});
    room.drawings.set(socket.id,data);
    if (room.drawings.size===room.players.size) {
      room.phase="guessing";
      room.order.forEach((id,i) => {
        const target=room.order[(i+1)%room.order.length];
        io.to(target).emit("your-task",{type:"guess", drawing:room.drawings.get(id), round:room.round});
      });
    }
    cb?.({ok:true}); broadcast(room);
  });
  socket.on("submit-guess", ({text}, cb) => {
    const room=rooms.get(socket.data.room);
    if (!room || room.phase!=="guessing" || !room.players.has(socket.id)) return;
    room.guesses.set(socket.id,String(text||"").trim().slice(0,100));
    if (room.guesses.size===room.players.size) {
      room.phase="reveal";
      const results=room.order.map((id,i)=>({
        player:room.players.get(id).name,
        phrase:room.prompts.get(id),
        drawing:room.drawings.get(room.order[(i+1)%room.order.length]),
        guess:room.guesses.get(room.order[(i+1)%room.order.length])
      }));
      io.to(room.code).emit("reveal", {results, round:room.round});
    }
    cb?.({ok:true}); broadcast(room);
  });
  socket.on("next-round", cb => {
    const room=rooms.get(socket.data.room);
    if (!room || room.phase!=="reveal" || [...room.players.keys()][0]!==socket.id) return;
    if (room.round>=room.totalRounds) {
      room.phase="finished"; io.to(room.code).emit("game-finished"); broadcast(room);
    } else {
      room.round++; room.phase="writing";
      room.prompts=new Map(); room.drawings=new Map(); room.guesses=new Map();
      room.players.forEach((_,id)=>room.prompts.set(id,null));
      io.to(room.code).emit("game-start",{round:room.round,totalRounds:room.totalRounds}); broadcast(room);
    }
    cb?.({ok:true});
  });
  socket.on("disconnect", () => {
    const c=socket.data.room, room=rooms.get(c);
    if (!room) return;
    room.players.delete(socket.id);
    if (!room.players.size) rooms.delete(c); else broadcast(room);
  });
});
const PORT=process.env.PORT||3000;
server.listen(PORT,()=>console.log(`Disegna e Disastra attivo sulla porta ${PORT}`));
